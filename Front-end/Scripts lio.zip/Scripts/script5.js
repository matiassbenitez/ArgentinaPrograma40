/*
Construir un programa que simule un menú de opciones para realizar las cuatro
operaciones aritméticas básicas (suma, resta, multiplicación y división) con dos valores
numéricos enteros. El usuario, además, debe especificar la operación con el primer
carácter de la operación que desea realizar: ‘S' o ‘s’ para la suma, ‘R’ o ‘r’ para la resta, ‘M’
o ‘m’ para la multiplicación y ‘D’ o ‘d’ para la división. 
*/

function calculadora(num1, num2, op) {

    switch (op) {
        case "S":
            return `La suma es ${parseInt(num1) + parseInt(num2)}`;
            break;
        case "R":
            return `La resta es ${parseInt(num1) - parseInt(num2)}`;
            break;
        case "M":
            return `El producto es ${parseInt(num1) * parseInt(num2)}`;
            break;
        case "D":
            return `La division es ${parseInt(num1) / parseInt(num2)}`;
            break;
    }
}



var op = prompt("Ingrese una operacion (S,R,M o D): ");
var num1 = prompt("Ingrese el primer número");
var num2 = prompt("Ingrese el segundo número");

alert(calculadora(num1, num2, op));
