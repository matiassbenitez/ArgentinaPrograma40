/*
Escribir un programa de JavaScript que a través de un formulario calcule el radio de un
circulo y lo muestre en el HTML.
*/

document.getElementById('circleForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const diameterInput = document.getElementById('diameter');
    const diameter = parseFloat(diameterInput.value);

    if (isNaN(diameter) || diameter <= 0) {
        alert('Por favor, ingresa un valor válido para el diámetro.');
        return;
    }

    const radius = diameter / 2;

    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `<p>El radio del círculo es: ${radius.toFixed(2)}</p>`;

    diameterInput.value = ''; // Limpiamos el valor del input
});
