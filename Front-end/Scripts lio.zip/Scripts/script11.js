/*
Escribir una función que reciba un String y devuelva la palabra más larga.
String Ejemplo: “Guia de JavaScript”
Resultado esperado : “JavaScript”
*/

function palabraMasLarga(cadena) {
    const palabras = cadena.split(' ');
   
    let palabraMasLarga = palabras[0];
   
    for (let i = 1; i < palabras.length; i++) {
      if (palabras[i].length > palabraMasLarga.length) {
        palabraMasLarga = palabras[i];
      }
    }
  
    return palabraMasLarga;
  }
  
  
  const frase = prompt("Introduzca una frase");
  const resultado = palabraMasLarga(frase);
  alert("La palabra mas larga de su frase es: " + resultado); 

  /* Alternativa:
  function masLarga (frase){

    const palabras = frase.split(" ");
    let palabraMasLarga = palabras[0];

    palabras.forEach(palabra => {
        if(palabra.length > palabraMasLarga.length){
            palabraMasLarga = palabra
        }
    });
    return palabraMasLarga;

}

const frase = prompt("Ingresa una frase");

alert(`La palabra mas larga es ${masLarga(frase)}`)
  */