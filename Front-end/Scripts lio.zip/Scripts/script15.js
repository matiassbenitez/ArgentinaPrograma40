/*
. Escribe un programa JavaScript para calcular el área y el perímetro de un objeto Círculo
con la propiedad radio. Nota: Cree dos métodos para calcular el área y el perímetro. El
radio del círculo lo proporcionará el usuario.
*/


function calculaArea(radio) {
    var area = Math.PI * Math.pow(radio,2);
    return "El area es de: " + area + " cm2";
}

function calculaPerimetro(radio) {
    var perimetro = 2 * Math.PI * radio;
    return "El perimetro es de: " + perimetro + " cm";
}

var inputRadio = parseFloat(prompt("Introduzca el radio de su circunferencia"));


var resultados = "" + calculaArea(inputRadio) + "\n" + calculaPerimetro(inputRadio);

alert(resultados);
