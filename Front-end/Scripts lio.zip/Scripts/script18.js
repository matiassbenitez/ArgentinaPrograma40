/*
A partir del siguiente array: var valores = [true, 5, false, "hola", "adios", 2]:
a) Determinar cual de los dos elementos de texto es mayor
b) Utilizando exclusivamente los dos valores booleanos del array, determinar los
operadores necesarios para obtener un resultado true y otro resultado false
c) Determinar el resultado de las cinco operaciones matemáticas realizadas con los
dos elementos numéricos
*/

var palabras = [true, 5, false, "hola", "adios", 2, "OtraPalabraAcaYEstaEsMasLarga"];
var sumado = 0;
var restado = 0;
var dividido = 0;
var multiplicado = 0;


function esString(elemento) {
    return typeof elemento === "string";
}

function esBool(elemento) {
    return typeof elemento === "boolean";
}

function esNum(elemento) {
    return typeof elemento === "number";
}


var stringsEnArray = palabras.filter(esString);
var booleanEnArray = palabras.filter(esBool);
var numeroEnArray = palabras.filter(esNum);


function palabraMasLarga(palabras) {
    let palabraMasLarga = palabras[0];
    for (let i = 1; i < palabras.length; i++) {
        if (palabras[i].length > palabraMasLarga.length) {
            palabraMasLarga = palabras[i];
        }
    }
    return "La palabra mas larga es: " + palabraMasLarga;
}


function logicaBooleana(booleanEnArray) {
    console.log("Resultado &&:", booleanEnArray[0] && booleanEnArray[1]);
    console.log("Resultado ||:", booleanEnArray[0] || booleanEnArray[1]);
}


function sumResDivMult(numeroEnArray) {
    console.log("El resultado de la suma de los números es de: " + (parseInt(numeroEnArray[0] + parseInt(numeroEnArray[1]))))
    console.log("El resultado de la resta de los números es de: " + (parseInt(numeroEnArray[0] - parseInt(numeroEnArray[1]))))
    console.log("El resultado de la division de los números es de: " + (parseInt(numeroEnArray[0] / parseInt(numeroEnArray[1]))))
    console.log("El resultado de la multiplicacion de los números es de: " + (parseInt(numeroEnArray[0] * parseInt(numeroEnArray[1]))))
}
/*
function sumar() {
    for (let i = 0; i < numeroEnArray.length; i++) {
        sumado += parseInt(numeroEnArray[i]);
    }
    return sumado;
}

function restar() {
    for (let i = 0; i < numeroEnArray.length; i++) {
        restado = parseInt(numeroEnArray[i]) - parseInt(numeroEnArray[i]);
    }
    return restado;
}

function multiplicar() {
    for (let i = 0; i < numeroEnArray.length; i++) {
        multiplicado *= parseInt(numeroEnArray[i]);
    }
    return multiplicado;
}

function dividir() {
    for (let i = 0; i < numeroEnArray.length; i++) {
        dividido /= parseInt(numeroEnArray[i]);
    }
    return dividido;
}

console.log("El resultado de la suma de los números es de: " + sumar())
console.log("El resultado de la resta de los números es de: " + restar())
console.log("El resultado de la multiplicacion de los números es de: " + multiplicar())
console.log("El resultado de la division de los números es de: " + dividir())
*/
console.log(palabraMasLarga(stringsEnArray));
sumResDivMult(numeroEnArray);
logicaBooleana(booleanEnArray);