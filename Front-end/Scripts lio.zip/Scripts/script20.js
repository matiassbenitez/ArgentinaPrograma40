/*
Realizar un programa que obtenga la siguiente matriz [[3], [6], [9], [12], [15]] y devuelve y
muestre el siguiente array [6, 9, 12, 15, 18].
*/

var matriz = [[]];
var suma = 3
function llenarMatriz() {
    for (let i = 0; i < 5; i++) {
        matriz[i] = suma;
        suma += 3;
    }
}
llenarMatriz();
var stringified = matriz.toString();
var arrayed = stringified.split(",");


function upThree() {
    for (let i = 0; i < 5; i++) {
        arrayed[i] = parseInt(arrayed[i]);
    }
    for (let i = 0; i < 5; i++) {
        arrayed[i] = arrayed[i] + 3;

    }
}

console.log(arrayed);
upThree();
console.log(arrayed);