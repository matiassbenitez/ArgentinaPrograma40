/*
Escribir una función flecha de JavaScript que reciba un argumento y retorne el tipo de
dato.
*/

const tipoDato = (dato) => console.log(typeof dato);

tipoDato();