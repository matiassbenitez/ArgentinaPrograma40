/*
Realizar un programa que rellene dos vectores al mismo tiempo, con 5 valores aleatorios
y los muestre por pantalla. 
*/

var vector1 = [];
var vector2 = [];

function randomizer(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


for (let i = 0; i < 5; i++) {
        vector1[i] = randomizer(0,9999);
        vector2[i] = randomizer(0,9999);
 }

console.log("El contenido del vector 1 es: " + vector1);
console.log("El contenido del vector 2 es: " + vector2);