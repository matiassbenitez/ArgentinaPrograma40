/*
Crear un objeto libro que contenga las siguientes propiedades: ISBN, Título, Autor,
Número de páginas. Crear un método para cargar un libro pidiendo los datos al usuario
y luego informar mediante otro método el número de ISBN, el título, el autor del libro y el
numero de páginas.
*/

class Libro {
    ISBN;
    Titulo;
    Autor;
    NumPag;
}


function creaLibro() {
    var l1 = new Libro();
    l1.ISBN = prompt("Por favor introduzca el número ISBN");
    l1.Titulo = prompt("Ahora el título");
    l1.Autor = prompt("Ahora el autor");
    l1.NumPag = prompt("Y por último el número de páginas")

    return l1;
}

let l1 = creaLibro();

function mostrarLibro(l1) {
    console.log("El ISBN de su Libro es: " + l1.ISBN);
    console.log("El autor es:" + l1.Autor);
    console.log("El título es: " + l1.Titulo);
    console.log("Y tiene " + l1.NumPag + " páginas");
}

mostrarLibro(l1);