/*
Escriba un programa en el cual se ingrese un valor límite positivo, y a continuación
solicite números al usuario hasta que la suma de los números introducidos supere el
límite inicial. 
*/

function toTheLimit(limite){
    let suma = 0;
    while (suma < limite) {
        sumaUser = parseInt(prompt("Ingrese un número:"));
        suma = suma + sumaUser;
    }
    alert(`Te pasaste del límite por ${suma - limite}. La suma es ${suma}`);
}

var limite = prompt("Ingrese un número límite");
toTheLimit(limite);