/*
Realizar un programa que elimine los dos últimos elementos de un array. Mostrar el
resultado
*/

var arrayEntero = [0,1,2,3,4,5,6,7,8,9];

/* Alternativa
for (let i = 0; i < 2; i++) {
    arrayEntero.pop();
}
*/


arrayEntero.splice(-2);



console.log(arrayEntero);