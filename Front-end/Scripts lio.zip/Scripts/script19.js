/*
Realizar un programa en Java donde se creen dos arreglos: el primero será un arreglo A
de 50 números reales, y el segundo B, un arreglo de 20 números, también reales. El
programa deberá inicializar el arreglo A con números aleatorios y mostrarlo por pantalla.
Luego, el arreglo A se debe ordenar de menor a mayor y copiar los primeros 10 números
ordenados al arreglo B de 20 elementos, y rellenar los 10 últimos elementos con el valor
0.5. Mostrar los dos arreglos resultantes: el ordenado de 50 elementos y el combinado
de 20.
*/

var array1 = [];
var array1Ordenado = [];
var array2 = [];

function randomizer(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


function llenarArray1() {
    for (let i = 0; i < 50; i++) {
        array1.push(parseInt(randomizer(0,9999)));
    }
    console.log(array1);
}

function compNumeros(a, b) {
    if (a > b) return 1;
    if (a == b) return 0;
    if (a < b) return -1;
    }


function ordenarArray1(){
    array1Ordenado = array1.sort(compNumeros);
}


function llenarArray2() {
    for (let i = 0; i < 10; i++) {
        array2.push(array1Ordenado[i]);
    }
    for (let i = 0; i < 10; i++) {
        array2.push(0.5)
    }
}

llenarArray1();
ordenarArray1();
llenarArray2();

console.log(array2);
