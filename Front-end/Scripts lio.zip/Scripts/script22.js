/*
Escribir un programa de JavaScript que al clickear un botón muestre un mensaje a
elección.
*/

function mensajito() {
    alert("Wow este cartelito salió por que apretaste un botón!!!\nQuerés una galletita ?")
}

