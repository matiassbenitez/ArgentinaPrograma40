/*
Escribir un programa para obtener un array de las propiedades de un objeto Persona.
Las propiedades son nombre, edad, sexo ('H' hombre, 'M' mujer, 'O' otro), peso y altura. 
*/

class Persona {
    Nombre;
    Edad;
    Sexo;
    Peso;
    Altura;
}

var p1 = new Persona();
var contenido = [];
p1.Nombre = prompt("Por favor introduzca su nombre");
contenido.push(p1.Nombre);
p1.Edad = prompt("Ahora su edad");
contenido.push(p1.Edad);
p1.Sexo = prompt("Su sexo (Hombre, Mujer, Otro");
contenido.push(p1.Sexo);
p1.Peso = prompt("Su peso");
contenido.push(p1.Peso);
p1.Altura = prompt("Su Altura")
contenido.push(p1.Altura);

console.log(contenido);

