

function pintodeamarillo() {

    const paragraph = document.getElementById('textoCompleto');


    const wordsArray = paragraph.textContent.trim().split(' ');


    const longWords = wordsArray.filter(word => word.length > 8);

    longWords.forEach(word => {
        const regex = new RegExp(word, 'g');
        paragraph.innerHTML = paragraph.innerHTML.replace(regex, `<span style="background-color: yellow;">${word}</span>`);
    });

}



// Alternativa
// const miParrafo = document.getElementById('parrafo');
// var contenido = miParrafo.textContent;
// const palabras = contenido.split(' ');
// const palabrasResaltadas = palabras.map(palabra => {
//     return palabra.length > 8 ? `<strong class="resaltar">${palabra}</strong>` : palabra;
// });

// const nuevoContenido = palabrasResaltadas.join(' ');

// miParrafo.innerHTML = nuevoContenido;


