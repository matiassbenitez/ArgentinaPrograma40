/*
 Escriba una función de JavaScript para obtener los valores de Nombre y Apellido del
siguiente formulario.
*/

function getFormValores() {
    var form = document.getElementById("form1");
    var nombre = form.elements.nombre.value;
    var apellido = form.elements.apellido.value;
    alert(nombre);
    alert(apellido);
}