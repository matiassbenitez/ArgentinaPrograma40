package libreria;

import libreria.servicios.Servicio;

public class Libreria {

    public static void main(String[] args) {

        Servicio serv = new Servicio();

        serv.mostrarMenu();

    }
}
