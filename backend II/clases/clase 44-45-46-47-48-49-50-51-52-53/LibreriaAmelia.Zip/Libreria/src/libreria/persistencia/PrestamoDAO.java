
package libreria.persistencia;

import libreria.entidades.Prestamo;

public class PrestamoDAO extends DAO<Prestamo>{
    
}
