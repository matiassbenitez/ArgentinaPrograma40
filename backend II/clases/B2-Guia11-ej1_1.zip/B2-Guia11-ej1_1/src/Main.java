
import Entidad.Juego;
import Entidad.Jugador;
import Entidad.Revolver;
import Servicio.Servicio;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luna
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Servicio sv = new Servicio();
        ArrayList<Jugador> persona = new ArrayList();
        sv.cargarJugadores(persona);
        Revolver r = new Revolver();
        sv.llenarRevolver(r);
        Juego juego = new Juego();
        sv.llenarJuego(persona, r, juego);
        sv.ronda(juego);
    }
    
}
