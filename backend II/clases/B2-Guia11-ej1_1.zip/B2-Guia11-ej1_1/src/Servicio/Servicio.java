/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Juego;
import Entidad.Jugador;
import Entidad.Revolver;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Luna
 */
public class Servicio {
static Scanner entrada = new Scanner(System.in).useDelimiter("\n");
    /*
    llenarRevolver(): le pone los valores de posición actual y de posición del agua. Los valores
deben ser aleatorios.
     */
    public void llenarRevolver(Revolver r) {
        r.setPosicionActual((int) (Math.random() * 6) + 1);
        r.setBala((int) (Math.random() * 6) + 1);
    }
    public void cargarJugadores(ArrayList<Jugador> lista){
        System.out.println("Ingrese la cantidad de jugadores: ");
        int nJugadores;
         nJugadores = entrada.nextInt();
        while (nJugadores < 1) {
            System.out.println("Ingrese un numero correcto: ");
            nJugadores = entrada.nextInt();
        }
        if (nJugadores > 6) {
            nJugadores = 6;
        }
        for (int i = 0; i < nJugadores; i++) {
            lista.add(new Jugador(i+1));
        }
    }

    /**
     * • mojar(): devuelve true si la posición del agua coincide con la posición
     * actual
     */
    public boolean mojar(Revolver r) {
        boolean bandera = false;
        if (r.getBala() == r.getPosicionActual()) {
            bandera = true;
        }
        return bandera;
    }

    /**
     * siguienteChorro(): cambia a la siguiente posición del tambor
     */
    public void siguienteChorro(Revolver r) {
        System.out.println("Posición actual: " + r.getPosicionActual());
        System.out.println("Bala: " + r.getBala());
        /**
         * 4
         * 5
         */
        if (r.getPosicionActual() == 6) {
            r.setPosicionActual(1);
        } else {
            r.setPosicionActual(r.getPosicionActual() + 1);
        }
    }

    /**
     * toString(): muestra información del revolver (posición actual y donde
     * está el agua
     */
    /**
     * disparo(Revolver r): el método, recibe el revolver de agua y llama a los
     * métodos de mojar() y siguienteChorro() de Revolver. El jugador se apunta,
     * aprieta el gatillo y si el revolver tira el agua, el jugador se moja. El
     * atributo mojado pasa a false y el método devuelve true, sino false.
     */
    public boolean disparo(Revolver r, Jugador jugador) {
        if (this.mojar(r)) {
            jugador.setMojado(true);
        }
        this.siguienteChorro(r);
        return jugador.isMojado();
    }

    /**
     * }llenarJuego(ArrayList<Jugador>jugadores, Revolver r): este método recibe
     * los jugadores y el revolver para guardarlos en los atributos del juego.
     */
    public void llenarJuego(ArrayList<Jugador> jugadores, Revolver r, Juego juego) {
        juego.setJugadores(jugadores);
        juego.setR(r);
    }
    /**
     * ronda(): cada ronda consiste en un jugador que se apunta con el revolver
     * de agua y aprieta el gatillo. Sí el revolver tira el agua el jugador se
     * moja y se termina el juego, sino se moja, se pasa al siguiente jugador
     * hasta que uno se moje. Si o si alguien se tiene que mojar. Al final del
     * juego, se debe mostrar que jugador se mojó. Pensar la lógica necesaria
     * para realizar esto, usando los atributos de la clase Juego.
     */
    public void ronda(Juego juego){
        int c = 0 ;
        boolean bandera = false;
        do {
            bandera = this.disparo(juego.getR(), juego.getJugadores().get(c));
            if (juego.getJugadores().get(c).isMojado()) {
                System.out.println(juego.getJugadores().get(c).getNombre()+" Se mojo:");
            }else{
                c++;
                /**
                 *  4
                 *  1 % 4 = 1:
                 * 2 % 4 = 2;
                 * 3 % 4 = 3;
                 * 4 % 4 = 0;
                 */ 
                c = c % juego.getJugadores().size();
            }
            
        } while (!bandera);
        
    }
}
